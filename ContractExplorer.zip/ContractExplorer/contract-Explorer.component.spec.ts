import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ContractExplorerComponent } from './contract-Explorer.component';

describe('ContractExplorerComponent', () => {
  let component: ContractExplorerComponent;
  let fixture: ComponentFixture<ContractExplorerComponent>;

  beforeEach((() => {
    TestBed.configureTestingModule({
      declarations: [ ContractExplorerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractExplorerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
