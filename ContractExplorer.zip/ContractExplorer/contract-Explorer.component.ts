import { Component, OnInit, AfterViewInit,Injectable } from '@angular/core';
import { UserProfile } from 'src/app/_models';
import { UserPermission } from 'src/app/_models/usermanagement/userpermission';
import { NgxSpinnerService } from "ngx-spinner";;
import { AuthenticationService, UserService } from 'src/app/services/usermanagement';
import { ActivatedRoute, Router } from '@angular/router';
import { Group } from 'src/app/_models/contractprocessing/group';
import { Subgroup } from 'src/app/_models/contractprocessing/subgroup';
import { ContractProcessingService } from 'src/app/services/contractprocessing/contractprocessing.service';
import { ContractBatchRequestDetails } from 'src/app/_models/contractprocessing/contractbatchrequestdetails';
import { ContractFramework, TodoItemFlatNode, TodoItemNode } from 'src/app/_models/contractframework/contractframework';
import { BehaviorSubject } from 'rxjs';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlattener, MatTreeFlatDataSource } from '@angular/material/tree';
import { SelectionModel } from '@angular/cdk/collections';
import { ContractStructure } from 'src/app/_models/contractstructure/contractstructure';
import { ParentToParagraph } from 'src/app/_models/paragraph/parenttoparagraph';

var API_DATA = [
    {
      "nodeId": 897,
      "nodeName": "2008 Member Contract",
      "parent": 1,
      "contractType": "2008 Member Contract",
      "level": 1,
      "priority": 0,
      "systemNode": true,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 898,
      "nodeName": "Member Contract",
      "parent": 897,
      "contractType": "2008 Member Contract",
      "level": 2,
      "priority": 1,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 899,
      "nodeName": "Benefit Summary",
      "parent": 898,
      "contractType": "2008 Member Contract",
      "level": 3,
      "priority": 3,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 900,
      "nodeName": "Cover",
      "parent": 898,
      "contractType": "2008 Member Contract",
      "level": 3,
      "priority": 2,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 901,
      "nodeName": "Endorsements",
      "parent": 898,
      "contractType": "2008 Member Contract",
      "level": 3,
      "priority": 1,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 902,
      "nodeName": "EOC",
      "parent": 898,
      "contractType": "2008 Member Contract",
      "level": 3,
      "priority": 4,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 903,
      "nodeName": "Riders",
      "parent": 898,
      "contractType": "2008 Member Contract",
      "level": 3,
      "priority": 5,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 904,
      "nodeName": "Disclaimers",
      "parent": 898,
      "contractType": "2008 Member Contract",
      "level": 3,
      "priority": 6,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 905,
      "nodeName": "Alt Care",
      "parent": 903,
      "contractType": "2008 Member Contract",
      "level": 4,
      "priority": 2,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 906,
      "nodeName": "Drug",
      "parent": 903,
      "contractType": "2008 Member Contract",
      "level": 4,
      "priority": 5,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 907,
      "nodeName": "Vision",
      "parent": 903,
      "contractType": "2008 Member Contract",
      "level": 4,
      "priority": 10,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 908,
      "nodeName": "Hearing Aid",
      "parent": 903,
      "contractType": "2008 Member Contract",
      "level": 4,
      "priority": 7,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 945,
      "nodeName": "Ortho",
      "parent": 903,
      "contractType": "2008 Member Contract",
      "level": 4,
      "priority": 12,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 947,
      "nodeName": "MedImpact",
      "parent": 906,
      "contractType": "2008 Member Contract",
      "level": 5,
      "priority": 1,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 949,
      "nodeName": "Expanded Choice",
      "parent": 903,
      "contractType": "2008 Member Contract",
      "level": 4,
      "priority": 6,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 961,
      "nodeName": "Travel",
      "parent": 903,
      "contractType": "2008 Member Contract",
      "level": 4,
      "priority": 9,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 964,
      "nodeName": "Cosmetic Surgery",
      "parent": 903,
      "contractType": "2008 Member Contract",
      "level": 4,
      "priority": 4,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 1007,
      "nodeName": "Accidental Dental",
      "parent": 903,
      "contractType": "2008 Member Contract",
      "level": 4,
      "priority": 1,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 1008,
      "nodeName": "Infertility",
      "parent": 903,
      "contractType": "2008 Member Contract",
      "level": 4,
      "priority": 8,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 1009,
      "nodeName": "Vision Pedi",
      "parent": 903,
      "contractType": "2008 Member Contract",
      "level": 4,
      "priority": 11,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 1020,
      "nodeName": "Bariatric Surgery",
      "parent": 1007,
      "contractType": "2008 Member Contract",
      "level": 5,
      "priority": 1,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    },
    {
      "nodeId": 1021,
      "nodeName": "Bariatric Surgery",
      "parent": 903,
      "contractType": "2008 Member Contract",
      "level": 4,
      "priority": 3,
      "systemNode": false,
      "textColor": "Black",
      "frameworkId": 43,
      "framework": null,
      "parentsToParagraphs": []
    }
  ]
  var FILE_DATA=[
    {
        "name":"11thly Rule.doc",
        "defaultPriority":0,
        "defaultParent":911,
        "FileExtension":"doc"
    },
    {
      "name":"13BI_13BF_POS_HD_2-Tier.doc",
      "defaultPriority":0,
      "defaultParent":903,
      "FileExtension":"doc"
    
    },
    {
      "name":"13SI_13SF_POS_HD_2-Tier.pdf",
      "defaultPriority":0,
      "defaultParent":899,
      "FileExtension":"pdf"
    
    },
    {
      "name":"16238-009_R_HMO_XX_3TRX-NONECOV(1-1-2016).doc",
      "defaultPriority":0,
      "defaultParent":906,
      "FileExtension":"doc"
    
    },
    {
      "name":"16238-015_R_HMO_XX_3TRX-NONECOV(1-1-2016).pdf",
      "defaultPriority":0,
      "defaultParent":906,
      "FileExtension":"pdf"
    
    },
    {
      "name":"16238-018_Ded_HMO_XX_BS-INFOCOV_GF.pdf",
      "defaultPriority":0,
      "defaultParent":899,
      "FileExtension":"pdf"
    
    },
    {
      "name":"16238-015_R_Ded_HMO_XX_3TRX-NONECOV(1-1-2016).pdf",
      "defaultPriority":0,
      "defaultParent":906,
      "FileExtension":"pdf"
    
    },
    ]
  @Injectable()
export class ChecklistDatabase {
  dataChange = new BehaviorSubject<TodoItemNode[]>([]);
  nodeId!: any;
  nodeCondition!: any;
  get data(): TodoItemNode[] { return this.dataChange.value; }

  constructor() {
    this.initialize();
  }

  initialize() {
    // Build the tree nodes from Json object. The result is a list of `TodoItemNode` with nested
    //     file node as children.
    
    this.nodeId = "";
    this.nodeCondition = {};
    const data = this.findNodes(this.nodeId, this.nodeCondition);

    // Notify the change.
    this.dataChange.next(data);
  }

  insertParagraphItem(parent: TodoItemNode, parentToParagraph: any) {
    if(parent.paragraphlist.length==0)
    {    
     //var fileList= JSON.parse(JSON.stringify(parentToParagraph, undefined, 4));
     var fileList= JSON.parse(JSON.stringify(parentToParagraph));
     console.log(fileList)
     var data=fileList.filter((e: { defaultParent: number; })=>e.defaultParent==parent.nodeId);  
     console.log(parent.nodeId)
     console.log(data)
     if(!parent.children)
     parent.children=[];
    if(data.length>0)
    {
     parent.paragraphlist=data;
      for(let i=0;i<data.length;i++)
      {
       parent.children.unshift({ nodeName: data[i].name,parent:data[i].defaultParent, nodeId:data[i].id} as TodoItemNode);
     
      }
       console.log(parent)
      this.dataChange.next(this.data);
    }
   } 
}


  partial(arr: any[], condition: any) {
    const result = [];
    for (let i = 0; i < arr.length; i++) {
      if (condition(arr[i])) {
        result.push(arr[i]);
      }
    }
    return result;
  }

  findNodes(parentKey: any, items: any[]) {
    let subItems = this.partial(items, (n: { parent: any; }) => n.parent === parentKey);
    const result = [];
    console.log("test")
    console.log(parentKey)
    console.log(subItems)
    for (let i = 0; i < subItems.length; i++) {
      let node = new TodoItemNode();
      let subItem = subItems[i];
      node.nodeId = subItem.nodeId;
      node.nodeName = subItem.nodeName;
      node.parent = subItem.parent;
      node.contractType = subItem.contractType;
      node.frameworkId = subItem.frameworkId;
      node.paragraphlist=[];
      let kids = this.findNodes(subItem.nodeId, items);

      if (kids.length) {
        node.children = kids;
      }
      result.push(node);
    }
    return result;
  }

  /**
   * Build the file structure tree. The `value` is the Json object, or a sub-tree of a Json object.
   * The return value is the list of `TodoItemNode`.
   */
  buildFileTree(obj: { [key: string]: any }, level: number): TodoItemNode[] {
    return Object.keys(obj).reduce<TodoItemNode[]>((accumulator, key) => {
      const value = obj[key];
      const node = new TodoItemNode();
      node.nodeName = key;

      if (value != null) {
        if (typeof value === 'object') {
          node.children = this.buildFileTree(value, level + 1);
        } else {
          node.nodeName = value;
        }
      }

      return accumulator.concat(node);
    }, []);
  }

  /** Add an item to to-do list */
  insertItem(parent: TodoItemNode, name: string) {
    if (parent.children) {
      parent.children.push({ item: name } as unknown as TodoItemNode);
      this.dataChange.next(this.data);
    }
  }

  updateItem(node: TodoItemNode, name: string) {
    node.nodeName = name;
    this.dataChange.next(this.data);
  }
}


@Component({
    selector: 'contractExplorer',
    templateUrl: './contract-Explorer.component.html',
    styleUrls: ['./contract-Explorer.component.css'],
    providers: [ChecklistDatabase]
})


export class ContractExplorerComponent implements OnInit, AfterViewInit {
    
    user!: UserProfile;
    UserPermission: UserPermission[] = [];
    group!: Group;
    subGroups!: Subgroup[];
    error: any;
    contractBatchRequestDetails!: ContractBatchRequestDetails[];
    totalCount: number = 0;
    paramBatchId: any;
    currentPage = 1;
    contractStructure!: ContractStructure[];
    stringifiedContractStructures!: any;
    contractName!: string;
    parentNode!: any;
    parentToParagraph! : ParentToParagraph[];


    /** Map from flat node to nested node. This helps us finding the nested node to be modified */
  flatNodeMap = new Map<TodoItemFlatNode, TodoItemNode>();

  /** Map from nested node to flattened node. This helps us to keep the same object for selection */
  nestedNodeMap = new Map<TodoItemNode, TodoItemFlatNode>();

  /** A selected parent node to be inserted */
  selectedParent: TodoItemFlatNode | null = null;

  /** The new item's name */
  newItemName = '';

  treeControl: FlatTreeControl<TodoItemFlatNode>;

  treeFlattener: MatTreeFlattener<TodoItemNode, TodoItemFlatNode>;

  dataSource: MatTreeFlatDataSource<TodoItemNode, TodoItemFlatNode>;

  /** The selection for checklist */
  checklistSelection = new SelectionModel<TodoItemFlatNode>(true /* multiple */);
  map: any;



    
    constructor(private route: ActivatedRoute, public _userService: UserService, public _contractProcessingService: ContractProcessingService,private _database: ChecklistDatabase,
        private _spinnerService: NgxSpinnerService, private router: Router, private authenticationService: AuthenticationService) {
        this.user = this.authenticationService.userValue.userProfile;
        this.UserPermission = this.authenticationService.userValue.userPermission;

        this.treeFlattener = new MatTreeFlattener(this.transformer, this.getLevel,
            this.isExpandable, this.getChildren);
          this.treeControl = new FlatTreeControl<TodoItemFlatNode>(this.getLevel, this.isExpandable);
          this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
    }

    
  getLevel = (node: TodoItemFlatNode) => node.level;

  isExpandable = (node: TodoItemFlatNode) => node.expandable;

  getChildren = (node: TodoItemNode): TodoItemNode[] => node.children;

  hasChild = (_: number, _nodeData: TodoItemFlatNode) => _nodeData.expandable;

  hasNoContent = (_: number, _nodeData: TodoItemFlatNode) => { return _nodeData.nodeName === ''; };

  /**
   * Transformer to convert nested node to flat node. Record the nodes in maps for later use.
   */
  transformer = (node: TodoItemNode, level: number) => {
    let flatNode = this.nestedNodeMap.has(node) && this.nestedNodeMap.get(node)!.nodeName === node.nodeName
      ? this.nestedNodeMap.get(node)!
      : new TodoItemFlatNode();
    flatNode.nodeName = node.nodeName;
    flatNode.level = level;
    flatNode.expandable = !!node.children;
    flatNode.nodeId = node.nodeId;
    flatNode.nodeParentId = node.parent;
    this.flatNodeMap.set(flatNode, node);
    this.nestedNodeMap.set(node, flatNode);
    return flatNode;
  }


    ngAfterViewInit() {
    }

    ngOnInit() {
        this.paramBatchId = this.route.snapshot.queryParamMap.get('id');
        this.GetContractBatchRequestDetailsById(this.paramBatchId);
        this.selectContractFramework()
        console.log("Test Mess")
    }

    handlePageChange(event: number): void {
        this.currentPage = event;
    }

    RouterBackToContractProcessing()
    {
        this.router.navigate(['/contractProcessing']);
    }

    Evaluate() {

    }

    Build() {

    }


    loadFileItem(node: TodoItemFlatNode) {
        //this._spinnerService.show();
        this.getContractStructureParagraph(node?.nodeId);
        //console.log("spinner time started");
        
          
          this.parentNode = this.flatNodeMap.get(node);  
          console.log(this.parentNode)
          console.log(this.parentToParagraph)
          if (this.parentToParagraph != null)    
          {
          this._database.insertParagraphItem(this.parentNode!, this.parentToParagraph);
         // this._spinnerService.hide();
          //console.log("spinner timeout after "+this.spinnerDuration);
          }
          else{
            console.log("No Paragraph Documents Available");
          }     
     }

     getContractStructureParagraph(nodeId: number)
     {   
      // this._parentToParagraphService.getParagraphsByParentId(nodeId).subscribe((parentToparagraphTask : any) => {    
        var fileList= JSON.parse(JSON.stringify(FILE_DATA, undefined, 4));
       // var data=fileList.filter((e: { defaultParent: number; })=>e.defaultParent==nodeId);
        console.log(fileList)             
         this.parentToParagraph = fileList;
         console.log(this.parentToParagraph);
      // },
        //  (error) => {
        //    this.error = error;  
        //    console.log(error);      
        //  });
     }

    selectContractFramework() {
       // if (event.target.innerText != null) {
         // this.contractKey = this.filteredContractFrameworks.filter(x => x.name == event.target.innerText);
        // if (this.contractKey != null && this.contractKey[0].key != null) {
           // this._manageContractStructureService.getContractStructureByFrameWorkId(this.contractKey[0].key).subscribe(contractStructure => {
              var contractStructure = JSON.parse(JSON.stringify(API_DATA,undefined,4))
             // this.contractName = this.contractKey[0].name;
              this.stringifiedContractStructures = JSON.parse(JSON.stringify(contractStructure));
             // console.log(this,this.stringifiedContractStructures);
              var firstNode =JSON.parse(JSON.stringify(contractStructure));
            //  console.log(firstNode);
              const tree = this._database.findNodes(firstNode[0].nodeId, JSON.parse(JSON.stringify(contractStructure)));
             // console.log(tree);
              this._database.dataChange.next(tree);
              this._database.dataChange.subscribe(() => {
              this.dataSource.data = tree;
             // console.log("-----");
             // console.log(this.dataSource.data);
              });          
           // },
            //   (error) => {
            //     this.error = error;
            //     console.log(error);
            //   });
         // }
       // }
      }

    GetContractBatchRequestDetailsById(batchId: number) {
        setTimeout(() => {
            this._contractProcessingService.GetContractBatchRequestDetailsById(batchId).subscribe(batchRequestDetail => {
                this.contractBatchRequestDetails = batchRequestDetail.contractBatchRequestDetails;
                this.totalCount = batchRequestDetail.totalCount;
                // console.log(this.contractBatchRequestDetails);
                // console.log(this.totalCount);                
            },
                (error) => {
                    this.error = error;
                    console.log(error);
                });
        }, 2000);
    }

    Print() {

    }
}